<footer class="main-footer">
    <div class="container">
        <p>&copy; Akcent - All Rights Reserved</p>
       <!-- <div class="social-links">
         <a href="#">Facebook</a> | <a href="#">Instagram</a> | <a href="#">Twitter</a> 
        </div> --> 
    </div>
</footer>