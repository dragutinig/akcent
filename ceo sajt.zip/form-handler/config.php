<?php
return [
  'smtp_host' => 'mail.akcent.rs',
  'smtp_user' => 'kontakt@akcent.rs',
  'smtp_pass' => 'Dragigagi1',
  'smtp_port' => 465,
  'to_email'  => 'akcentnamestaj@gmail.com',
  'send_autoreply' => true
];
